# Jemal Tahir Mumed – Personal Portfolio

A responsive personal website built with React and Tailwind CSS.

## Features

- Resume download
- Highlighted projects and research
- Contact form UI
- Mobile responsiveness

## Setup

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## License

MIT © 2025 Jemal Tahir Mumed
